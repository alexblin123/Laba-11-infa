﻿#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;

struct Node {
    char* data;
    Node* next;
};

Node* createNode(const char* d) {

    Node* newNode = new Node;
    newNode->data = new char[strlen(d) + 1];
    strcpy_s(newNode->data, strlen(d) + 1, d);
    newNode->next = nullptr;
    return newNode;
}

Node* enqueue(Node* rear, const char* newData) {
    Node* newNode = createNode(newData);

    if (rear == nullptr) {
        return newNode;
    }
    else {
        rear->next = newNode;
        return newNode;
    }
}

Node* dequeue(Node* front, const char* key) {
    Node* current = front;
    Node* prev = nullptr;

    while (current != nullptr && strcmp(current->data, key) != 0) {
        prev = current;
        current = current->next;
    }

    if (current == nullptr) {
        cout << "Элемент с ключом " << key << " не найден в очереди." << endl;
        return front;
    }

    if (prev == nullptr) {
        Node* newFront = front->next;
        delete[] front->data;
        delete front;
        return newFront;
    }
    else {
        prev->next = current->next;
        delete[] current->data;
        delete current;
        return front;
    }
}

Node* insertBefore(Node* front, int position, int K, const char* newData) {
    Node* newNode = createNode(newData);

    if (position == 1) {
        for (int i = 0; i < K; ++i) {
            newNode->next = front;
            front = newNode;
            newNode = createNode(newData);
        }
    }
    else {
        Node* current = front;
        Node* prev = nullptr;
        int currentPosition = 1;

        while (current != nullptr && currentPosition < position) {
            prev = current;
            current = current->next;
            currentPosition++;
        }

        if (current == nullptr) {
            cout << "Позиция " << position << " не найдена в очереди." << endl;
            return front;
        }

        for (int i = 0; i < K; ++i) {
            Node* tmp = createNode(newData);
            if (tmp == nullptr) {
                tmp->next = front;
                front = tmp;
            }
            else {
                tmp->next = current;
                prev->next = tmp;
            }
            prev = tmp;
        }
    }
    return front;
}

void displayQueue(Node* front) {
    Node* current = front;
    while (current != nullptr) {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

void writeQueueToFile(Node* front, const char* fileName) {
    ofstream outputFile(fileName);

    if (!outputFile.is_open()) {
        cerr << "Не удалось открыть файл для записи." << endl;
        return;
    }

    Node* current = front;
    while (current != nullptr) {
        outputFile << current->data << " ";
        current = current->next;
    }

    cout << "Очередь успешно записана в файл: " << fileName << endl;
    outputFile.close();
}

int main() {

    system("chcp 1251>nul");

    Node* front = nullptr;
    Node* rear = nullptr;

    int choice;
    char data[100];

    do {
        cout << endl << "Операции: " << endl;
        cout << "\t1. Добавить в очередь" << endl;
        cout << "\t2. Удалить по ключу" << endl;
        cout << "\t3. Вставить перед" << endl;
        cout << "\t4. Вывод очереди" << endl;
        cout << "\t5. Выход из программы" << endl;
        cout << endl << "Выберете операцию: "; cin >> choice;

        switch (choice) {
        case 1:
            cout << endl << "Введите данные для добавления: ";
            cin >> data;
            rear = enqueue(rear, data);
            if (front == nullptr) {
                front = rear;
            }
            break;
        case 2:
            cout << endl << "Введите ключ на удаление: "; cin >> data;
            front = dequeue(front, data);
            break;
        case 3:
            int position, K;
            cout << endl << "Введите позицию, перед которой вставить: "; cin >> position;
            cout << endl << "Введите кол-во элементов, которые нужно вставить: "; cin >> K;
            cout << endl << "Введите данные: ";  cin >> data;
            front = insertBefore(front, position, K, data);
            cout << endl;
            break;
        case 4:
            cout << endl << "Очередь: ";
            displayQueue(front);
            cout << endl;
            break;
        case 5:
            cout << "Выход из программы." << endl;
            break;
        default:
            cout << endl << "Недопустимый ввод. Выберете операцию еще раз." << endl;
        }

    } while (choice != 5);

    const char* outputFileName = "output.txt";
    writeQueueToFile(front, outputFileName);

    // Очистка памяти
    while (front != nullptr) {
        Node* temp = front;
        front = front->next;
        delete[] temp->data;
        delete temp;
    }

    return 0;
}
