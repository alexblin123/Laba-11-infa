﻿#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

struct Node {
    char* data;
    Node* next;
};

void push(Node** top, char* value) {
    Node* newNode = new Node;
    newNode->data = new char[strlen(value) + 1];
    strcpy_s(newNode->data, strlen(value) + 1, value);
    newNode->next = *top;
    *top = newNode;

    cout << "Элемент " << value << " добавлен в стек." << endl;
}

void deleteElement(Node** top, char* key) {
    if (*top == nullptr) {
        cout << "Стек пуст." << endl;
        return;
    }

    Node* current = *top;
    Node* previous = nullptr;

    while (current != nullptr) {
        if (strcmp(current->data, key) == 0) {
            if (previous == nullptr) {
                *top = current->next;
            }
            else {
                previous->next = current->next;
            }

            delete[] current->data;
            delete current;

            cout << "Элемент с ключом " << key << " удален из стека." << endl;
            return;
        }

        previous = current;
        current = current->next;
    }

    cout << "Элемент с ключом " << key << " не найден в стеке." << endl;
}

void insertBefore(Node** top, char* value, int position, int K) {
    Node* current = *top;
    Node* previous = nullptr;
    int count = 1;

    while (current != nullptr && count != position) {
        previous = current;
        current = current->next;
        count++;
    }

    if (count != position) {
        cout << "Позиция для вставки не найдена." << endl;
        return;
    }

    for (int i = 0; i < K; i++) {
        Node* newNode = new Node;
        newNode->data = new char[strlen(value) + 1];
        strcpy_s(newNode->data, strlen(value) + 1, value);
        newNode->next = current;

        if (previous == nullptr) {
            *top = newNode;
        }
        else {
            previous->next = newNode;
        }

        previous = newNode;
    }

    cout << "Элемент " << value << " вставлен перед позицией " << position << " в стеке." << endl;
}

void displayStack(Node* top) {

    Node* current = top;
    cout << "Стек: ";
    while (current != nullptr) {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

void writeFile(Node* top) {

    ofstream file("stack.txt");

    if (!file.is_open()) {
        cout << endl << "Ошибка открытия файла для записи." << endl;
        return;
    }

    Node* current = top;

    while (current != nullptr) {
        file << current->data << endl;
        current = current->next;
    }

    file.close();
    cout << endl << "Данные стека успешно записаны в файл." << endl;
}

int main() {

    system("chcp 1251>nul");

    Node* top = nullptr;
    char value[100];
    int choice;

    do {
        cout << endl << "Выберите действие:" << endl;
        cout << "\t1. Добавить элемент в стек" << endl;
        cout << "\t2. Удалить элемент по ключу" << endl;
        cout << "\t3. Вставить элемент перед позицией" << endl;
        cout << "\t4. Вывести стек" << endl;
        cout << "\t5. Записать стек в файл" << endl;
        cout << "\t0. Выход" << endl;
        cout << endl << "Действие: ";  cin >> choice;

        switch (choice) {

        case 1:
            cout << endl << "Введите элемент для добавления в стек: "; cin >> value;
            push(&top, value);
            break;
        case 2:
            cout << endl << "Введите ключ элемента для удаления: ";  cin >> value;
            deleteElement(&top, value);
            break;
        case 3:
            int position, K;
            cout << endl << "Введите значение элемента для вставки: "; cin >> value;
            cout << endl << "Введите позицию для вставки и количество вставок: "; cin >> position >> K;
            insertBefore(&top, value, position, K);
            break;
        case 4:
            displayStack(top);
            break;
        case 5:
            writeFile(top);
            break;
        case 0:
            cout << endl << "Программа завершена." << endl;
            break;
        default:
            cout << endl << "Неверный ввод. Попробуйте снова." << endl;
        }
    } while (choice != 0);

    // очистка памяти
    while (top != nullptr) {

        Node* temp = top;
        top = top->next;
        delete[] temp->data;
        delete temp;
    }

    return 0;
}
